"""Search engine: indexing/retrieval, external web search (Brave), query analysis, ranking and scoring, Afaan Oromoo handling, suggestions, evaluation."""
