-keepattributes Signature, *Annotation*, InnerClasses, EnclosingMethod
# Gson models (reflection)
-keep class com.mave.app.data.** { *; }
-dontwarn okhttp3.**
-dontwarn retrofit2.**
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.annotations.**
