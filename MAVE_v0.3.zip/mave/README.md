# MAVE – AI Search Engine (v0.3)

Barbaacha AI'n deeggarame: **index mataa (crawler + BM25)** + **web search** + **deebii AI maddoo waliin** + Android app.

## Qabiyyee
```
android/   Kotlin + Jetpack Compose app
backend/   FastAPI + SQLite FTS5 search engine
```

## 1. Backend jalqabuu
```
cd backend
pip install -r requirements.txt
cp .env.example .env            # MAVE_JWT_SECRET, MAVE_ADMIN_KEY, BRAVE_API_KEY, ANTHROPIC_API_KEY
export $(grep -v '^#' .env | xargs)
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Docker: `docker compose up --build` (backend/ keessatti).
Key hin kaa'in taanaan demo data/demo answer ni deebisa.

### Index mataa kee ijaaruu (MAVE'n Google irraa adda kan taasisu)
```
python crawl.py seeds.txt --pages 500 --depth 2 --delay 1.0
# ykn server irraa:
curl -X POST localhost:8000/admin/crawl -H "X-Admin-Key: $MAVE_ADMIN_KEY" \
     -H "content-type: application/json" -d '{"seeds":["https://om.wikipedia.org/"],"max_pages":300}'
curl localhost:8000/admin/stats -H "X-Admin-Key: $MAVE_ADMIN_KEY"
```
Crawler: robots.txt ni kabaja, domain tokkoof yeroo 1s eeggata, domain seed qofa keessa hafa, `seeds.txt` jijjiiri.
Ranking: BM25 (title ×6) + title match + link popularity + freshness + domain diversity → Brave results waliin RRF fusion.

### Endpoints
**API v1**: hundi `/api/v1/...` jalatti ni jira (fkn `GET /api/v1/search`); karaa duraa (`/search`, ...) clients 0.2 tiif ni hafe.
`GET /search?q=&type=web|tech|news|images|videos` · `GET /suggest?q=` · `GET /trending` · `POST /ai/answer` · `GET /me`
`POST /auth/register|login` · `GET/POST/DELETE /me/history` · `GET/POST/DELETE /me/saved`
`POST /admin/crawl` · `GET /admin/stats` · `GET /health`

### Test
`python -m unittest discover -s tests -t . -v` (34 tests; API test fi provider test FastAPI/httpx install godhamee qofa — `pip install -r requirements.txt` booda hundi ni hojjata)

## 2. Android
1. `android/` Android Studio (Koala+) keessatti bani → Gradle sync → Run (emulator).
2. Debug build `http://10.0.2.2:8000/` fayyadama. Release: URL dhugaa `-PMAVE_API_URL=https://api.keessan.org/` (ykn `android/gradle.properties`) kenni; HTTPS ykn URL jiru hin kennin yoo ta'e release build ni fashaaleta.
3. Bilbila dhugaa irratti: `10.0.2.2` bakka IP kompiitara keetiin bay'ii.

Amaloota: onboarding, login/signup (token encrypted), autocomplete, "Did you mean", AI answer + sources,
Web/Images/Videos/News/Tech, voice search, saved + history (offline, DataStore) fi server waliin sync,
dark/light, Afaan Oromoo + English, error + retry.

## 3. Production checklist
- [x] `MAVE_ENV=production` → secret laafaa/hin kaa'amne yoo ta'e app hin eegalu; demo data/answer hin deebi'u; `/docs` cufame; HSTS ni kaa'ama
- [x] Crawler SSRF ittisa (`app/netguard.py`): localhost, IP dhuunfaa (10.x, 192.168.x, 169.254.169.254 ...), DNS rebinding, redirect hundi ni qoratama
- [x] Rate limit: `/auth/*` irratti ciccimoo (`MAVE_AUTH_RATE_LIMIT`), security headers, CORS (`MAVE_CORS_ORIGINS`)
- [ ] Gradle Wrapper guutuu: `cd android && gradle wrapper --gradle-version 8.9` yeroo tokko oofi `gradlew`, `gradlew.bat`, `gradle/wrapper/gradle-wrapper.jar` commit godhi
- [ ] `MAVE_JWT_SECRET`, `MAVE_ADMIN_KEY` jabaa kaa'i; HTTPS (Caddy/Nginx/Cloud Run) duuba; `MAVE_TRUST_PROXY=1`
- [ ] SQLite → PostgreSQL + OpenSearch yoo index >1M page ta'e
- [ ] Release signing key, Play Console, privacy policy
- [ ] `MAVE_BOT_URL` = fuula crawler keessan ibsu (User-Agent keessatti ni ergama)

## 4. Master Plan v1.0 — haala amma (v0.3)
| Phase | Haala |
|---|---|
| 1 Stabilize | **Xumurame (backend)**: test admin-stats (config import order) sirraa'e, URL fakkeenyaa mave.example haqame, API v1 prefix, `/me` |
| 4 Crawler (SSRF) | **Qabiyyee SSRF xumurame**; sitemap/scheduler/canonical/duplicate hin eegalamne |
| 6 Users | Hin eegalamne: refresh token, logout, forgot/reset password, email verification, account deletion |
| 2,3,5,7,8,9,10 | PostgreSQL/Redis/OpenSearch, hybrid search, grounded AI+citations, Android refactor, Web, Admin, CI/CD+monitoring — itti aanee |
