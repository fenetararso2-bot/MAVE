package com.mave.app.data

import com.mave.app.BuildConfig
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

/** Holds the bearer token in memory; persisted separately in encrypted storage. */
object Session {
    @Volatile
    var token: String? = null
}

interface MaveApi {
    @GET("search")
    suspend fun search(@Query("q") q: String, @Query("type") type: String): SearchResponse

    @GET("suggest")
    suspend fun suggest(@Query("q") q: String): SuggestResponse

    @GET("trending")
    suspend fun trending(): TrendingResponse

    @POST("ai/answer")
    suspend fun answer(@Body req: AiRequest): AiAnswer

    @POST("auth/login")
    suspend fun login(@Body req: AuthRequest): AuthResponse

    @POST("auth/register")
    suspend fun register(@Body req: AuthRequest): AuthResponse

    @GET("me/history")
    suspend fun history(): HistoryResponse

    @POST("me/history")
    suspend fun addHistory(@Body body: HistoryAdd): Ok

    @DELETE("me/history")
    suspend fun deleteHistory(@Query("q") q: String?): Ok

    @GET("me/saved")
    suspend fun saved(): SavedResponse

    @POST("me/saved")
    suspend fun addSaved(@Body item: SearchItem): Ok

    @DELETE("me/saved")
    suspend fun deleteSaved(@Query("url") url: String): Ok
}

object Network {
    private val auth = Interceptor { chain ->
        val token = Session.token
        val req = if (token != null) {
            chain.request().newBuilder().header("Authorization", "Bearer $token").build()
        } else chain.request()
        chain.proceed(req)
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(auth)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    val api: MaveApi by lazy {
        Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL + "api/v1/") // versioned API; server also keeps legacy root paths
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(MaveApi::class.java)
    }
}
