package com.mave.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.mave.app.MaveViewModel
import com.mave.app.data.SearchItem
import kotlinx.coroutines.delay

// ---------- Splash / Onboarding / Auth ----------

@Composable
fun SplashScreen(vm: MaveViewModel, onDone: () -> Unit) {
    LaunchedEffect(vm.loaded) {
        if (vm.loaded) {
            delay(900)
            onDone()
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "MAVE",
                fontSize = 52.sp,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
            Text("AI Search", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun OnboardingScreen(vm: MaveViewModel, onDone: () -> Unit) {
    val pages = listOf("ob1", "ob2", "ob3")
    var i by remember { mutableIntStateOf(0) }
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = vm.lang == "om", onClick = { vm.setLang("om") }, label = { Text("Afaan Oromoo") })
            FilterChip(selected = vm.lang == "en", onClick = { vm.setLang("en") }, label = { Text("English") })
        }
        Spacer(Modifier.height(32.dp))
        Text(
            L.t("${pages[i]}_t", vm.lang),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Text(L.t("${pages[i]}_d", vm.lang), textAlign = TextAlign.Center)
        Spacer(Modifier.height(32.dp))
        Button(onClick = { if (i < pages.lastIndex) i++ else onDone() }) {
            Text(L.t(if (i < pages.lastIndex) "next" else "start", vm.lang))
        }
        TextButton(onClick = onDone) { Text(L.t("skip", vm.lang)) }
    }
}

@Composable
fun AuthScreen(vm: MaveViewModel, onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "MAVE",
            fontSize = 40.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text(L.t("email", vm.lang)) },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text(L.t("password", vm.lang)) },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        vm.authError?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.authenticate(email, password, register, onDone) },
            modifier = Modifier.fillMaxWidth()
        ) { Text(L.t(if (register) "signup" else "login", vm.lang)) }
        TextButton(onClick = { register = !register }) {
            Text(L.t(if (register) "login" else "signup", vm.lang))
        }
        TextButton(onClick = onDone) { Text(L.t("guest", vm.lang)) }
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen(vm: MaveViewModel, onSearch: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "MAVE",
            fontSize = 48.sp,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary
        )
        Text(L.t("tagline", vm.lang), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))
        MaveSearchBar(vm, text, { text = it; vm.onTyping(it) }, { vm.clearSuggestions(); onSearch(it) })
        SuggestionList(vm) { text = it; vm.clearSuggestions(); onSearch(it) }
        Spacer(Modifier.height(20.dp))
        Text(L.t("trending", vm.lang), style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.trending) { t ->
                AssistChip(onClick = { onSearch(t) }, label = { Text(t) })
            }
        }
    }
}

// ---------- Results ----------

@Composable
fun ResultsScreen(vm: MaveViewModel, onBack: () -> Unit) {
    val tabs = listOf("ai", "web", "images", "videos", "news", "tech")
    var tab by remember { mutableIntStateOf(0) }
    var text by remember(vm.query) { mutableStateOf(vm.query) }
    val tabKey = tabs[tab]

    LaunchedEffect(vm.query, tabKey) { vm.loadTab(tabKey) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            MaveSearchBar(vm, text, { text = it; vm.onTyping(it) }, { vm.runSearch(it) })
        }
        SuggestionList(vm) { text = it; vm.runSearch(it) }
        ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
            tabs.forEachIndexed { idx, k ->
                Tab(selected = tab == idx, onClick = { tab = idx }, text = { Text(L.t(k, vm.lang)) })
            }
        }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.error?.let {
            Column(Modifier.padding(16.dp)) {
                Text(it, color = MaterialTheme.colorScheme.error)
                TextButton(onClick = { vm.retry(tabKey) }) { Text(L.t("retry", vm.lang)) }
            }
        }
        when (tabKey) {
            "ai" -> AiTab(vm)
            "images" -> ImagesTab(vm, vm.results["images"].orEmpty())
            else -> ListTab(vm, tabKey, vm.results[tabKey].orEmpty())
        }
    }
}

@Composable
fun AiTab(vm: MaveViewModel) {
    val a = vm.aiAnswer ?: return
    val uri = LocalUriHandler.current
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(Modifier.fillMaxWidth()) { Text(a.answer, Modifier.padding(16.dp)) }
        }
        item { Text(L.t("sources", vm.lang), style = MaterialTheme.typography.titleMedium) }
        itemsIndexed(a.sources) { i, s ->
            Text(
                "[${i + 1}] ${s.title}",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clickable { runCatching { uri.openUri(s.url) } }
            )
        }
    }
}

@Composable
fun ListTab(vm: MaveViewModel, tabKey: String, list: List<SearchItem>) {
    if (list.isEmpty() && !vm.loading && vm.error == null && vm.results.containsKey(tabKey)) {
        Text(L.t("no_results", vm.lang), Modifier.padding(16.dp))
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        val dym = vm.didYouMean
        if (tabKey == "web" && dym != null) {
            item {
                TextButton(onClick = { vm.runSearch(dym) }) {
                    Text("${L.t("did_you_mean", vm.lang)} $dym", fontWeight = FontWeight.SemiBold)
                }
            }
        }
        items(list) { item -> ResultCard(vm, item) }
    }
}

@Composable
fun ImagesTab(vm: MaveViewModel, list: List<SearchItem>) {
    val uri = LocalUriHandler.current
    if (list.isEmpty() && !vm.loading && vm.error == null && vm.results.containsKey("images")) {
        Text(L.t("no_results", vm.lang), Modifier.padding(16.dp))
    }
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(list) { item ->
            AsyncImage(
                model = item.thumbnail,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { runCatching { uri.openUri(item.url) } }
            )
        }
    }
}

// ---------- Saved / History / Profile / Settings ----------

@Composable
fun SavedScreen(vm: MaveViewModel) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Text(L.t("saved", vm.lang), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (vm.saved.isEmpty()) Text(L.t("empty", vm.lang))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vm.saved.toList()) { item -> ResultCard(vm, item) }
        }
    }
}

@Composable
fun HistoryScreen(vm: MaveViewModel, onSearch: (String) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                L.t("history", vm.lang),
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            if (vm.history.isNotEmpty()) {
                TextButton(onClick = { vm.clearHistory() }) { Text(L.t("clear", vm.lang)) }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (vm.history.isEmpty()) Text(L.t("empty", vm.lang))
        LazyColumn {
            items(vm.history.toList()) { q ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onSearch(q) }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(q, Modifier.weight(1f))
                    IconButton(onClick = { vm.removeHistory(q) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete")
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(vm: MaveViewModel, onLogin: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(24.dp)) {
        Text(L.t("profile", vm.lang), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        val u = vm.user
        if (u != null) {
            Text("${L.t("signed_in_as", vm.lang)}: $u")
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { vm.logout() }) { Text(L.t("logout", vm.lang)) }
        } else {
            Text(L.t("guest_name", vm.lang))
            Spacer(Modifier.height(12.dp))
            Button(onClick = onLogin) { Text(L.t("login", vm.lang)) }
        }
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onSettings) { Text(L.t("settings", vm.lang)) }
    }
}

@Composable
fun SettingsScreen(vm: MaveViewModel, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(L.t("settings", vm.lang), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(L.t("dark_mode", vm.lang), Modifier.weight(1f))
            Switch(checked = vm.darkMode, onCheckedChange = { vm.setDark(it) })
        }
        Spacer(Modifier.height(16.dp))
        Text(L.t("language", vm.lang), style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = vm.lang == "om", onClick = { vm.setLang("om") }, label = { Text("Afaan Oromoo") })
            FilterChip(selected = vm.lang == "en", onClick = { vm.setLang("en") }, label = { Text("English") })
        }
    }
}
