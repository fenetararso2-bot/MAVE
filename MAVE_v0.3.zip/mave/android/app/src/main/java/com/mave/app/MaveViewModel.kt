package com.mave.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mave.app.data.AiAnswer
import com.mave.app.data.AiRequest
import com.mave.app.data.AuthRequest
import com.mave.app.data.HistoryAdd
import com.mave.app.data.LocalStore
import com.mave.app.data.Network
import com.mave.app.data.Persisted
import com.mave.app.data.SearchItem
import com.mave.app.data.SecureStore
import com.mave.app.data.Session
import com.mave.app.ui.L
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import retrofit2.HttpException
import java.io.IOException

class MaveViewModel(app: Application) : AndroidViewModel(app) {
    private val store = LocalStore(app)
    private val secure = SecureStore(app)

    // App state (persisted)
    var loaded by mutableStateOf(false); private set
    var onboarded by mutableStateOf(false); private set
    var darkMode by mutableStateOf(false); private set
    var lang by mutableStateOf("om"); private set // "om" = Afaan Oromoo, "en" = English
    var user by mutableStateOf<String?>(null); private set
    val saved = mutableStateListOf<SearchItem>()
    val history = mutableStateListOf<String>()

    // Auth UI
    var authError by mutableStateOf<String?>(null); private set

    // Search state
    var query by mutableStateOf(""); private set
    var pending by mutableStateOf(0); private set
    val loading: Boolean get() = pending > 0
    var error by mutableStateOf<String?>(null); private set
    var aiAnswer by mutableStateOf<AiAnswer?>(null); private set
    var didYouMean by mutableStateOf<String?>(null); private set
    val results = mutableStateMapOf<String, List<SearchItem>>()
    private val inFlight = mutableSetOf<String>()

    var trending by mutableStateOf(listOf("Artificial Intelligence", "Afaan Oromoo", "Technology news", "Startups", "Kotlin"))
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList()); private set
    private var suggestJob: Job? = null

    init {
        viewModelScope.launch {
            val p = store.read()
            darkMode = p.dark ?: false
            lang = p.lang ?: "om"
            onboarded = p.onboarded ?: false
            saved.addAll(p.saved.orEmpty())
            history.addAll(p.history.orEmpty())
            val token = secure.token
            if (token != null && p.user != null) {
                Session.token = token
                user = p.user
            }
            loaded = true
            bg { trending = Network.api.trending().trending.ifEmpty { trending } }
            if (user != null) syncWithServer()
        }
    }

    // ---------------- helpers
    private fun persist() {
        val snap = Persisted(darkMode, lang, onboarded, user, saved.toList(), history.toList())
        viewModelScope.launch { store.write(snap) }
    }

    /** Fire-and-forget network work. Offline failures are fine: the local copy is the source of truth. */
    private fun bg(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: HttpException) {
                if (e.code() == 401 && Session.token != null) logout()
            } catch (e: Exception) {
                // ignore
            }
        }
    }

    private fun friendly(e: Exception): String = when {
        e is IOException -> L.t("err_network", lang)
        e is HttpException && e.code() == 429 -> L.t("err_rate", lang)
        e is HttpException && e.code() == 502 -> L.t("err_provider", lang)
        else -> L.t("err_server", lang)
    }

    // ---------------- settings
    fun setDark(v: Boolean) { darkMode = v; persist() }
    fun setLang(v: String) { lang = v; persist() }
    fun markOnboarded() { onboarded = true; persist() }

    // ---------------- search
    fun onTyping(text: String) {
        suggestJob?.cancel()
        if (text.isBlank()) { suggestions = emptyList(); return }
        suggestJob = viewModelScope.launch {
            delay(250)
            suggestions = try {
                Network.api.suggest(text.trim()).suggestions
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    fun clearSuggestions() { suggestJob?.cancel(); suggestions = emptyList() }

    fun runSearch(q: String) {
        val clean = q.trim()
        if (clean.isEmpty()) return
        clearSuggestions()
        history.remove(clean)
        history.add(0, clean)
        while (history.size > 100) history.removeAt(history.lastIndex)
        persist()
        if (Session.token != null) bg { Network.api.addHistory(HistoryAdd(clean)) }
        if (clean == query && (results.isNotEmpty() || aiAnswer != null)) return
        query = clean
        results.clear()
        aiAnswer = null
        didYouMean = null
        error = null
        inFlight.clear()
    }

    fun loadTab(tab: String) {
        val q = query
        if (q.isEmpty()) return
        val already = if (tab == "ai") aiAnswer != null else results.containsKey(tab)
        if (already || !inFlight.add(tab)) return
        viewModelScope.launch {
            pending++
            try {
                if (tab == "ai") {
                    aiAnswer = Network.api.answer(AiRequest(q, lang))
                } else {
                    val resp = Network.api.search(q, tab)
                    results[tab] = resp.results
                    if (tab == "web") didYouMean = resp.corrected
                }
                error = null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = friendly(e)
            } finally {
                inFlight.remove(tab)
                pending--
            }
        }
    }

    fun retry(tab: String) { error = null; loadTab(tab) }

    // ---------------- library
    fun isSaved(item: SearchItem) = saved.any { it.url == item.url }

    fun toggleSave(item: SearchItem) {
        val idx = saved.indexOfFirst { it.url == item.url }
        if (idx >= 0) {
            saved.removeAt(idx)
            if (Session.token != null) bg { Network.api.deleteSaved(item.url) }
        } else {
            saved.add(0, item)
            if (Session.token != null) bg { Network.api.addSaved(item) }
        }
        persist()
    }

    fun clearHistory() {
        history.clear(); persist()
        if (Session.token != null) bg { Network.api.deleteHistory(null) }
    }

    fun removeHistory(q: String) {
        history.remove(q); persist()
        if (Session.token != null) bg { Network.api.deleteHistory(q) }
    }

    // ---------------- auth
    fun authenticate(email: String, password: String, register: Boolean, onOk: () -> Unit) {
        val e = email.trim()
        if (!e.contains("@") || e.length < 5) { authError = L.t("err_email", lang); return }
        if (password.length < 8) { authError = L.t("err_pw_short", lang); return }
        viewModelScope.launch {
            try {
                val req = AuthRequest(e, password)
                val r = if (register) Network.api.register(req) else Network.api.login(req)
                Session.token = r.token
                secure.token = r.token
                user = r.email
                authError = null
                persist()
                onOk()
                syncWithServer()
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: HttpException) {
                authError = when (ex.code()) {
                    401 -> L.t("err_login", lang)
                    409 -> L.t("err_exists", lang)
                    else -> friendly(ex)
                }
            } catch (ex: Exception) {
                authError = friendly(ex)
            }
        }
    }

    fun logout() {
        Session.token = null
        secure.token = null
        user = null
        persist()
    }

    /** Merge server and local data (union), then push local-only items up. */
    private fun syncWithServer() = bg {
        val remoteSaved = Network.api.saved().items
        val remoteHistory = Network.api.history().items
        val localOnlySaved = saved.filter { s -> remoteSaved.none { it.url == s.url } }
        val localOnlyHistory = history.filter { it !in remoteHistory }
        saved.clear(); saved.addAll(localOnlySaved + remoteSaved)
        history.clear(); history.addAll((localOnlyHistory + remoteHistory).distinct().take(100))
        persist()
        localOnlySaved.forEach { Network.api.addSaved(it) }
        localOnlyHistory.reversed().forEach { Network.api.addHistory(HistoryAdd(it)) }
    }
}
