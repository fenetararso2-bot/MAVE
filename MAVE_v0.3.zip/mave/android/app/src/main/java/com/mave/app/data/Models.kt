package com.mave.app.data

data class SearchItem(
    val title: String,
    val url: String,
    val snippet: String,
    val thumbnail: String?
)

data class SearchResponse(val results: List<SearchItem>, val corrected: String? = null)

data class SuggestResponse(val suggestions: List<String>)

data class TrendingResponse(val trending: List<String>)

data class HistoryResponse(val items: List<String>)

data class SavedResponse(val items: List<SearchItem>)

data class HistoryAdd(val query: String)

data class Ok(val ok: Boolean)

data class AiRequest(val query: String, val lang: String)

data class AiAnswer(val answer: String, val sources: List<SearchItem>)

data class AuthRequest(val email: String, val password: String)

data class AuthResponse(val token: String, val email: String)
