"""A polite web crawler (robots.txt, per-domain delay, size limits). Stdlib only."""
import re
import time
import urllib.error
import urllib.request
from html.parser import HTMLParser
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit
from urllib.robotparser import RobotFileParser

from .config import settings
from .db import db
from .index import add_link_counts, upsert_document
from .netguard import BlockedURL, safe_urlopen
from .textutil import detect_lang

SKIP_TAGS = {"script", "style", "noscript", "svg", "template", "iframe"}
BAD_EXT = re.compile(
    r"\.(jpg|jpeg|png|gif|webp|svg|ico|pdf|zip|gz|rar|mp3|mp4|avi|mov|css|js|json|xml|woff2?|ttf|exe|apk|dmg)$", re.I
)
MAX_BYTES = 2_000_000


class PageParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.title = ""
        self.meta_desc = ""
        self.html_lang: str | None = None
        self.links: list[str] = []
        self._text: list[str] = []
        self._skip = 0
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "html" and a.get("lang"):
            self.html_lang = a["lang"]
        if tag in SKIP_TAGS:
            self._skip += 1
        elif tag == "title":
            self._in_title = True
        elif tag == "a" and a.get("href"):
            rel = (a.get("rel") or "").lower()
            if "nofollow" not in rel:
                self.links.append(a["href"])
        elif tag == "meta" and (a.get("name") or "").lower() == "description":
            self.meta_desc = a.get("content") or ""

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS and self._skip:
            self._skip -= 1
        elif tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data
        elif not self._skip:
            self._text.append(data)

    @property
    def text(self) -> str:
        return re.sub(r"\s+", " ", " ".join(self._text)).strip()


def normalize_url(url: str) -> str | None:
    try:
        p = urlsplit(url.strip())
    except ValueError:
        return None
    if p.scheme not in ("http", "https") or not p.netloc:
        return None
    netloc = p.netloc.lower()
    if (p.scheme == "http" and netloc.endswith(":80")) or (p.scheme == "https" and netloc.endswith(":443")):
        netloc = netloc.rsplit(":", 1)[0]
    if BAD_EXT.search(p.path):
        return None
    query = urlencode([(k, v) for k, v in parse_qsl(p.query) if not k.lower().startswith(("utm_", "fbclid", "gclid"))])
    return urlunsplit((p.scheme, netloc, p.path or "/", query, ""))


def fetch_url(url: str, timeout: float = 10.0) -> tuple[str, str]:
    """Return (final_url, html). Raises on non-HTML, errors, oversize or SSRF-blocked targets (BlockedURL)."""
    req = urllib.request.Request(url, headers={"User-Agent": settings.bot_name, "Accept": "text/html"})
    with safe_urlopen(req, timeout=timeout) as resp:
        ctype = resp.headers.get("Content-Type", "")
        if "html" not in ctype.lower():
            raise ValueError(f"not html: {ctype}")
        raw = resp.read(MAX_BYTES)
        m = re.search(r"charset=([\w-]+)", ctype, re.I)
        charset = m.group(1) if m else "utf-8"
        try:
            html = raw.decode(charset, errors="replace")
        except LookupError:
            html = raw.decode("utf-8", errors="replace")
        return resp.geturl(), html


class Crawler:
    def __init__(
        self,
        fetcher=fetch_url,
        db_path: str | None = None,
        max_pages: int = 100,
        max_depth: int = 2,
        delay: float = 1.0,
        stay_on_seed_domains: bool = True,
        respect_robots: bool = True,
    ):
        self.fetcher = fetcher
        self.db_path = db_path
        self.max_pages = max_pages
        self.max_depth = max_depth
        self.delay = delay
        self.stay = stay_on_seed_domains
        self.respect_robots = respect_robots
        self._robots: dict[str, RobotFileParser | None] = {}
        self._last_hit: dict[str, float] = {}
        self._seed_domains: set[str] = set()

    # ---- robots.txt
    def _allowed(self, url: str) -> bool:
        if not self.respect_robots:
            return True
        p = urlsplit(url)
        origin = f"{p.scheme}://{p.netloc}"
        if origin not in self._robots:
            rp = RobotFileParser()
            try:
                req = urllib.request.Request(origin + "/robots.txt", headers={"User-Agent": settings.bot_name})
                with safe_urlopen(req, timeout=8) as r:
                    rp.parse(r.read(500_000).decode("utf-8", errors="replace").splitlines())
                self._robots[origin] = rp
            except urllib.error.HTTPError as e:
                # 4xx = no robots file -> allowed; 5xx = be conservative
                self._robots[origin] = None if e.code < 500 else RobotFileParser()
                if e.code >= 500:
                    self._robots[origin].disallow_all = True
            except Exception:
                rp.disallow_all = True
                self._robots[origin] = rp
        rp = self._robots[origin]
        return True if rp is None else rp.can_fetch(settings.bot_name, url)

    def _wait(self, domain: str) -> None:
        last = self._last_hit.get(domain)
        if last is not None and self.delay > 0:
            remaining = self.delay - (time.time() - last)
            if remaining > 0:
                time.sleep(remaining)
        self._last_hit[domain] = time.time()

    # ---- frontier
    def add_seeds(self, seeds: list[str]) -> int:
        n = 0
        with db(self.db_path) as con:
            for s in seeds:
                u = normalize_url(s)
                if not u:
                    continue
                self._seed_domains.add(urlsplit(u).netloc)
                cur = con.execute(
                    "INSERT OR IGNORE INTO frontier(url, depth, status, added_at) VALUES(?,0,'pending',?)",
                    (u, time.time()),
                )
                n += cur.rowcount
        return n

    def _next(self, con):
        return con.execute(
            "SELECT url, depth FROM frontier WHERE status='pending' ORDER BY depth, added_at LIMIT 1"
        ).fetchone()

    def run(self, seeds: list[str] | None = None) -> dict:
        if seeds:
            self.add_seeds(seeds)
        else:
            with db(self.db_path) as con:
                for r in con.execute("SELECT url FROM frontier"):
                    self._seed_domains.add(urlsplit(r["url"]).netloc)
        with db(self.db_path) as con:  # recover from an interrupted run
            con.execute("UPDATE frontier SET status='pending' WHERE status='working'")
        indexed = failed = blocked = 0
        while indexed < self.max_pages:
            with db(self.db_path) as con:
                row = self._next(con)
                if not row:
                    break
                url, depth = row["url"], row["depth"]
                con.execute("UPDATE frontier SET status='working' WHERE url=?", (url,))
            domain = urlsplit(url).netloc
            if not self._allowed(url):
                blocked += 1
                self._mark(url, "blocked")
                continue
            self._wait(domain)
            try:
                final_url, html = self.fetcher(url)
            except BlockedURL:  # SSRF policy: never count/retry internal targets as ordinary failures
                blocked += 1
                self._mark(url, "blocked")
                continue
            except Exception:
                failed += 1
                self._mark(url, "failed")
                continue
            parser = PageParser()
            try:
                parser.feed(html)
            except Exception:
                failed += 1
                self._mark(url, "failed")
                continue
            text = parser.text
            body = (parser.meta_desc + " " + text).strip()
            title = re.sub(r"\s+", " ", parser.title).strip() or final_url
            links = []
            for href in parser.links:
                nu = normalize_url(urljoin(final_url, href))
                if nu:
                    links.append(nu)
            with db(self.db_path) as con:
                if len(text) >= 80:
                    upsert_document(con, normalize_url(final_url) or final_url, title, body, detect_lang(text, parser.html_lang))
                    indexed += 1
                add_link_counts(con, links)
                if depth < self.max_depth:
                    for nu in dict.fromkeys(links):
                        if self.stay and urlsplit(nu).netloc not in self._seed_domains:
                            continue
                        con.execute(
                            "INSERT OR IGNORE INTO frontier(url, depth, status, added_at) VALUES(?,?, 'pending', ?)",
                            (nu, depth + 1, time.time()),
                        )
                con.execute("UPDATE frontier SET status='done' WHERE url=?", (url,))
        return {"indexed": indexed, "failed": failed, "blocked": blocked}

    def _mark(self, url: str, status: str) -> None:
        with db(self.db_path) as con:
            con.execute("UPDATE frontier SET status=? WHERE url=?", (status, url))
