"""Indexing and local retrieval on top of SQLite FTS5 (BM25)."""
import math
import sqlite3
import time

from .ranking import diversify
from .textutil import content_tokens, fts_query, host, make_snippet

MAX_BODY = 200_000


def upsert_document(con: sqlite3.Connection, url: str, title: str, body: str, lang: str | None = None) -> None:
    con.execute(
        """INSERT INTO documents(url, domain, title, body, lang, fetched_at)
           VALUES(?,?,?,?,?,?)
           ON CONFLICT(url) DO UPDATE SET
             title=excluded.title, body=excluded.body, lang=excluded.lang, fetched_at=excluded.fetched_at""",
        (url, host(url), (title or url)[:300], (body or "")[:MAX_BODY], lang, time.time()),
    )


def add_link_counts(con: sqlite3.Connection, urls: list[str]) -> None:
    con.executemany(
        "INSERT INTO link_counts(url, n) VALUES(?,1) ON CONFLICT(url) DO UPDATE SET n = n + 1",
        [(u,) for u in set(urls)],
    )


def _run(con: sqlite3.Connection, match: str, limit: int, lang: str | None):
    sql = """
        SELECT d.url, d.domain, d.title, d.body, d.lang, d.fetched_at,
               COALESCE(l.n, 0) AS inlinks,
               bm25(docs_fts, 6.0, 1.0) AS bm
        FROM docs_fts
        JOIN documents d ON d.id = docs_fts.rowid
        LEFT JOIN link_counts l ON l.url = d.url
        WHERE docs_fts MATCH ?
    """
    args: list = [match]
    if lang:
        sql += " AND d.lang = ?"
        args.append(lang)
    sql += " ORDER BY bm LIMIT ?"
    args.append(limit)
    return con.execute(sql, args).fetchall()


def search_local(con: sqlite3.Connection, q: str, limit: int = 20, offset: int = 0, lang: str | None = None) -> list[dict]:
    """BM25 candidates -> rerank with title match, link popularity and freshness -> diversify by domain."""
    match = fts_query(q, "and")
    if not match:
        return []
    candidates = 150
    try:
        rows = _run(con, match, candidates, lang)
        if len(rows) < 5:  # widen recall with OR when AND is too strict
            seen = {r["url"] for r in rows}
            rows += [r for r in _run(con, fts_query(q, "or"), candidates, lang) if r["url"] not in seen]
    except sqlite3.OperationalError:
        return []

    q_toks = content_tokens(q)
    now = time.time()
    scored = []
    for r in rows:
        relevance = -r["bm"]  # bm25() is negative, lower is better
        title_low = r["title"].lower()
        title_hits = sum(t in title_low for t in q_toks) / max(len(q_toks), 1)
        popularity = 0.25 * math.log1p(r["inlinks"])
        age_days = max(0.0, (now - r["fetched_at"]) / 86400)
        freshness = 0.3 * math.exp(-age_days / 180)
        score = relevance + 1.5 * title_hits + popularity + freshness
        scored.append(
            {
                "title": r["title"],
                "url": r["url"],
                "snippet": make_snippet(r["body"], q_toks),
                "thumbnail": None,
                "domain": r["domain"],
                "score": score,
            }
        )
    scored.sort(key=lambda x: x["score"], reverse=True)
    scored = diversify(scored, per_domain=2, window=10)
    return scored[offset : offset + limit]


def stats(con: sqlite3.Connection) -> dict:
    one = lambda sql: con.execute(sql).fetchone()[0]  # noqa: E731
    return {
        "documents": one("SELECT COUNT(*) FROM documents"),
        "domains": one("SELECT COUNT(DISTINCT domain) FROM documents"),
        "frontier_pending": one("SELECT COUNT(*) FROM frontier WHERE status='pending'"),
        "frontier_done": one("SELECT COUNT(*) FROM frontier WHERE status='done'"),
        "frontier_failed": one("SELECT COUNT(*) FROM frontier WHERE status='failed'"),
        "queries_logged": one("SELECT COUNT(*) FROM query_log"),
        "users": one("SELECT COUNT(*) FROM users"),
    }
