"""Runtime configuration.

Every value is read from the environment *when it is accessed*, not when this module is imported.
This matters because several modules do ``from .config import settings`` at import time: with eager
evaluation, whichever test (or process) imported the app first froze the configuration, so later
changes to MAVE_ADMIN_KEY / MAVE_DB were silently ignored (the admin-stats test failure).
"""
import os
import secrets

_fallback_jwt_secret: str | None = None


def _env(name: str, default: str = "") -> str:
    return os.environ.get(name, default)


def _int(name: str, default: int) -> int:
    try:
        return int(_env(name, str(default)))
    except ValueError:
        return default


class Settings:
    @property
    def env(self) -> str:
        return _env("MAVE_ENV", "development").strip().lower()

    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @property
    def db_path(self) -> str:
        return _env("MAVE_DB", "mave.db")

    @property
    def jwt_secret(self) -> str:
        # Without MAVE_JWT_SECRET tokens die on every restart. The random fallback is generated once
        # per process (never per access) and is rejected outright in production, see validate().
        global _fallback_jwt_secret
        explicit = _env("MAVE_JWT_SECRET")
        if explicit:
            return explicit
        if _fallback_jwt_secret is None:
            _fallback_jwt_secret = secrets.token_hex(32)
        return _fallback_jwt_secret

    @property
    def admin_key(self) -> str:
        return _env("MAVE_ADMIN_KEY")

    @property
    def brave_key(self) -> str:
        return _env("BRAVE_API_KEY")

    @property
    def anthropic_key(self) -> str:
        return _env("ANTHROPIC_API_KEY")

    @property
    def model(self) -> str:
        return _env("MAVE_MODEL", "claude-sonnet-5-5")

    @property
    def rate_limit_per_min(self) -> int:
        return _int("MAVE_RATE_LIMIT", 90)

    @property
    def trust_proxy(self) -> bool:
        return _env("MAVE_TRUST_PROXY") == "1"

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip() for o in _env("MAVE_CORS_ORIGINS").split(",") if o.strip()]

    @property
    def bot_name(self) -> str:
        # Set MAVE_BOT_URL to the public page describing your crawler; no placeholder URL is shipped.
        url = _env("MAVE_BOT_URL").strip()
        return f"MAVEBot/0.3 (+{url})" if url else "MAVEBot/0.3"

    @property
    def auth_rate_limit_per_min(self) -> int:
        # Stricter limit for login/register/refresh to slow down password guessing.
        return min(_int("MAVE_AUTH_RATE_LIMIT", 10), self.rate_limit_per_min)

    def validate(self) -> list[str]:
        """Problems that make the configuration unsafe for production (startup must fail)."""
        problems = []
        if len(_env("MAVE_JWT_SECRET")) < 32 or _env("MAVE_JWT_SECRET").startswith("change-me"):
            problems.append("MAVE_JWT_SECRET must be set to a random value of at least 32 characters")
        key = self.admin_key
        if len(key) < 16 or key.startswith("change-me"):
            problems.append("MAVE_ADMIN_KEY must be set to a random value of at least 16 characters")
        return problems

    def warnings(self) -> list[str]:
        """Non-fatal production gaps."""
        out = []
        if not self.brave_key:
            out.append("BRAVE_API_KEY is not set: external web search is unavailable")
        if not self.anthropic_key:
            out.append("ANTHROPIC_API_KEY is not set: AI answers are unavailable")
        if not self.cors_origins:
            out.append("MAVE_CORS_ORIGINS is empty: browsers on other origins (web app) will be refused")
        return out


settings = Settings()
