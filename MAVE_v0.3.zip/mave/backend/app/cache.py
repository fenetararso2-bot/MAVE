import time
from collections import OrderedDict


class TTLCache:
    def __init__(self, ttl: float = 300, maxsize: int = 512):
        self.ttl, self.maxsize = ttl, maxsize
        self._d: OrderedDict = OrderedDict()

    def get(self, key):
        v = self._d.get(key)
        if not v:
            return None
        if v[0] < time.time():
            self._d.pop(key, None)
            return None
        self._d.move_to_end(key)
        return v[1]

    def set(self, key, value):
        self._d[key] = (time.time() + self.ttl, value)
        self._d.move_to_end(key)
        while len(self._d) > self.maxsize:
            self._d.popitem(last=False)
