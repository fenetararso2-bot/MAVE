"""MAVE API. Run: uvicorn app.main:app --host 0.0.0.0 --port 8000"""
import hmac
import re
import sqlite3
import time
from collections import defaultdict, deque

from fastapi import APIRouter, BackgroundTasks, Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from . import __version__, providers, suggest as sg
from .cache import TTLCache
from .config import settings
from .crawler import Crawler
from .db import db, init_db
from .index import search_local, stats
from .ranking import rrf_fuse
from .security import check_password, hash_password, make_token, verify_token

if settings.is_production:  # fail fast instead of running with guessable secrets
    _problems = settings.validate()
    if _problems:
        raise RuntimeError("Unsafe production configuration: " + "; ".join(_problems))
    for _w in settings.warnings():
        print("WARNING:", _w)

_docs = {} if not settings.is_production else {"docs_url": None, "redoc_url": None, "openapi_url": None}
app = FastAPI(title="MAVE API", version=__version__, **_docs)
router = APIRouter()  # mounted at /api/v1 (and at the root for MAVE <= 0.2 clients), see bottom of file
init_db()

# ------------------------------------------------------------------ rate limiting
_hits: dict[str, deque] = defaultdict(deque)


@app.middleware("http")
async def rate_limit(request: Request, call_next):
    ip = request.client.host if request.client else "unknown"
    if settings.trust_proxy:
        ip = request.headers.get("x-forwarded-for", ip).split(",")[0].strip()
    limit = settings.rate_limit_per_min
    if "/auth/" in request.url.path:
        ip, limit = "auth:" + ip, settings.auth_rate_limit_per_min
    now = time.time()
    if len(_hits) > 10_000:  # purge idle clients so the table cannot grow forever
        for k in [k for k, v in _hits.items() if not v or now - v[-1] > 60]:
            del _hits[k]
    q = _hits[ip]
    while q and now - q[0] > 60:
        q.popleft()
    if len(q) >= limit:
        return JSONResponse({"detail": "Too many requests"}, status_code=429, headers={"Retry-After": "30"})
    q.append(now)
    return await call_next(request)


@app.exception_handler(providers.ProviderError)
async def provider_error(_: Request, exc: providers.ProviderError):
    return JSONResponse({"detail": str(exc)}, status_code=502)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    resp = await call_next(request)
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    path = request.url.path
    if path not in ("/docs", "/redoc"):  # Swagger/ReDoc (development only) need to load their own assets
        resp.headers.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
    if "/auth/" in path or "/me" in path or "/admin/" in path:
        resp.headers.setdefault("Cache-Control", "no-store")
    if settings.is_production:
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    return resp


if settings.cors_origins:  # web client origins, e.g. MAVE_CORS_ORIGINS=https://app.example.org
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type"],
        max_age=600,
    )


# ------------------------------------------------------------------ models
class AuthReq(BaseModel):
    email: str = Field(min_length=5, max_length=254)
    password: str = Field(min_length=8, max_length=128)


class AiReq(BaseModel):
    query: str = Field(min_length=1, max_length=300)
    lang: str = "en"


class HistoryReq(BaseModel):
    query: str = Field(min_length=1, max_length=200)


class SavedReq(BaseModel):
    title: str = Field(max_length=300)
    url: str = Field(max_length=2000)
    snippet: str = Field(default="", max_length=1000)
    thumbnail: str | None = Field(default=None, max_length=2000)


class CrawlReq(BaseModel):
    seeds: list[str] = Field(min_length=1, max_length=50)
    max_pages: int = Field(default=100, ge=1, le=5000)
    max_depth: int = Field(default=2, ge=0, le=5)
    delay: float = Field(default=1.0, ge=0.2, le=10)


# ------------------------------------------------------------------ auth
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")


def current_user(authorization: str | None = Header(default=None)) -> dict:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Missing token")
    data = verify_token(authorization[7:].strip())
    if not data:
        raise HTTPException(401, "Invalid or expired token")
    return data


def require_admin(x_admin_key: str | None = Header(default=None)) -> None:
    if not settings.admin_key:
        raise HTTPException(403, "Admin API disabled (set MAVE_ADMIN_KEY)")
    if not x_admin_key or not hmac.compare_digest(x_admin_key, settings.admin_key):
        raise HTTPException(403, "Forbidden")


@router.post("/auth/register")
def register(req: AuthReq):
    email = req.email.strip().lower()
    if not EMAIL.fullmatch(email):
        raise HTTPException(400, "Invalid email")
    salt, pw = hash_password(req.password)
    try:
        with db() as con:
            cur = con.execute(
                "INSERT INTO users(email, salt, pw_hash, created_at) VALUES(?,?,?,?)", (email, salt, pw, time.time())
            )
            uid = cur.lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Email already registered")
    return {"token": make_token(uid, email), "email": email}


@router.post("/auth/login")
def login(req: AuthReq):
    email = req.email.strip().lower()
    with db() as con:
        row = con.execute("SELECT id, salt, pw_hash FROM users WHERE email=?", (email,)).fetchone()
    if not row or not check_password(req.password, row["salt"], row["pw_hash"]):
        raise HTTPException(401, "Wrong email or password")
    return {"token": make_token(row["id"], email), "email": email}


# ------------------------------------------------------------------ search
_logged = TTLCache(ttl=600, maxsize=5000)


def _should_log(request: Request, q: str) -> bool:
    ip = request.client.host if request.client else "unknown"
    key = (ip, q.lower())
    if _logged.get(key):
        return False
    _logged.set(key, True)
    return True


def _local(q: str, page: int, size: int, log: bool = False):
    with db() as con:
        if log:
            sg.log_query(con, q)
        items = search_local(con, q, limit=size, offset=(page - 1) * size)
        corrected = sg.spell_correct(con, q) if page == 1 else None
        n_docs = con.execute("SELECT COUNT(*) FROM documents").fetchone()[0]
    for it in items:
        it["source"] = "mave"
    return items, corrected, n_docs


@router.get("/search")
async def search(
    request: Request,
    q: str = Query(min_length=1, max_length=300),
    type: str = "web",
    page: int = Query(default=1, ge=1, le=20),
):
    if type not in providers.BRAVE_PATHS:
        raise HTTPException(400, "Invalid type")
    q = " ".join(q.split())
    size = 20
    corrected = None
    lists, weights = [], []
    if type in ("web", "tech"):
        log = page == 1 and _should_log(request, q)
        local, corrected, _ = await run_in_threadpool(_local, q, page, size, log)
        if local:
            lists.append(local)
            weights.append(1.3)  # own index gets a boost: it is the product's differentiator
    try:
        web = await providers.web_search(q, type, count=size, offset=(page - 1) * size)
        lists.append(web)
        weights.append(1.0)
    except providers.ProviderError:
        if not lists:  # no local results either -> surface the error
            raise
    results = rrf_fuse(lists, weights) if len(lists) > 1 else (lists[0] if lists else [])
    for r in results:
        r.pop("score", None)
        r.pop("domain", None)
    return {"results": results, "corrected": corrected, "page": page}


@router.get("/suggest")
def suggest(q: str = Query(min_length=1, max_length=100)):
    with db() as con:
        return {"suggestions": sg.suggest(con, q)}


@router.get("/trending")
def trending():
    with db() as con:
        return {"trending": sg.trending(con)}


@router.post("/ai/answer")
async def ai_answer(req: AiReq, request: Request):
    q = " ".join(req.query.split())
    log = _should_log(request, q)
    local, _, _ = await run_in_threadpool(_local, q, 1, 5, log)
    try:
        web = await providers.web_search(q, "web", count=8)
    except providers.ProviderError:
        web = []
    sources = rrf_fuse([local, web], [1.3, 1.0])[:6] if local and web else (local or web)[:6]
    for s in sources:
        s.pop("score", None)
        s.pop("domain", None)
    if not sources:
        return {"answer": "No sources found for this question.", "sources": []}
    answer = await providers.ai_answer(q, sources, req.lang)
    return {"answer": answer, "sources": sources}


# ------------------------------------------------------------------ per-user data
@router.get("/me")
def me(user: dict = Depends(current_user)):
    with db() as con:
        row = con.execute("SELECT id, email, created_at FROM users WHERE id=?", (user["sub"],)).fetchone()
    if not row:
        raise HTTPException(401, "Account no longer exists")
    return {"id": row["id"], "email": row["email"], "created_at": row["created_at"]}


@router.get("/me/history")
def get_history(user: dict = Depends(current_user)):
    with db() as con:
        rows = con.execute(
            "SELECT query FROM history WHERE user_id=? ORDER BY ts DESC LIMIT 200", (user["sub"],)
        ).fetchall()
    return {"items": [r["query"] for r in rows]}


@router.post("/me/history")
def add_history(req: HistoryReq, user: dict = Depends(current_user)):
    with db() as con:
        con.execute(
            """INSERT INTO history(user_id, query, ts) VALUES(?,?,?)
               ON CONFLICT(user_id, query) DO UPDATE SET ts=excluded.ts""",
            (user["sub"], req.query.strip(), time.time()),
        )
    return {"ok": True}


@router.delete("/me/history")
def delete_history(q: str | None = None, user: dict = Depends(current_user)):
    with db() as con:
        if q:
            con.execute("DELETE FROM history WHERE user_id=? AND query=?", (user["sub"], q))
        else:
            con.execute("DELETE FROM history WHERE user_id=?", (user["sub"],))
    return {"ok": True}


@router.get("/me/saved")
def get_saved(user: dict = Depends(current_user)):
    with db() as con:
        rows = con.execute(
            "SELECT title, url, snippet, thumbnail FROM saved WHERE user_id=? ORDER BY ts DESC LIMIT 500",
            (user["sub"],),
        ).fetchall()
    return {"items": [dict(r) for r in rows]}


@router.post("/me/saved")
def add_saved(req: SavedReq, user: dict = Depends(current_user)):
    if not req.url.lower().startswith(("http://", "https://")):
        raise HTTPException(400, "Invalid url")
    with db() as con:
        con.execute(
            """INSERT INTO saved(user_id, url, title, snippet, thumbnail, ts) VALUES(?,?,?,?,?,?)
               ON CONFLICT(user_id, url) DO UPDATE SET title=excluded.title, ts=excluded.ts""",
            (user["sub"], req.url, req.title, req.snippet, req.thumbnail, time.time()),
        )
    return {"ok": True}


@router.delete("/me/saved")
def delete_saved(url: str, user: dict = Depends(current_user)):
    with db() as con:
        con.execute("DELETE FROM saved WHERE user_id=? AND url=?", (user["sub"], url))
    return {"ok": True}


# ------------------------------------------------------------------ admin / ops
def _crawl_job(req: CrawlReq) -> None:
    Crawler(max_pages=req.max_pages, max_depth=req.max_depth, delay=req.delay).run(req.seeds)


@router.post("/admin/crawl", dependencies=[Depends(require_admin)])
def admin_crawl(req: CrawlReq, bg: BackgroundTasks):
    bg.add_task(_crawl_job, req)
    return {"started": True, "seeds": len(req.seeds)}


@router.get("/admin/stats", dependencies=[Depends(require_admin)])
def admin_stats():
    with db() as con:
        return stats(con)


@router.get("/health")
def health():
    return {"ok": True, "version": __version__}


# ------------------------------------------------------------------ mount
app.include_router(router, prefix="/api/v1")
app.include_router(router, include_in_schema=False)  # legacy un-prefixed paths for MAVE <= 0.2 clients
