import sqlite3
from contextlib import contextmanager

from .config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  salt BLOB NOT NULL,
  pw_hash BLOB NOT NULL,
  created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS history(
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  query TEXT NOT NULL,
  ts REAL NOT NULL,
  UNIQUE(user_id, query)
);
CREATE TABLE IF NOT EXISTS saved(
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  snippet TEXT NOT NULL DEFAULT '',
  thumbnail TEXT,
  ts REAL NOT NULL,
  UNIQUE(user_id, url)
);
CREATE TABLE IF NOT EXISTS query_log(
  id INTEGER PRIMARY KEY,
  query TEXT NOT NULL,
  ts REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_qlog_ts ON query_log(ts);

CREATE TABLE IF NOT EXISTS documents(
  id INTEGER PRIMARY KEY,
  url TEXT UNIQUE NOT NULL,
  domain TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  lang TEXT,
  fetched_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_docs_domain ON documents(domain);
CREATE TABLE IF NOT EXISTS link_counts(
  url TEXT PRIMARY KEY,
  n INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS frontier(
  url TEXT PRIMARY KEY,
  depth INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  added_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_frontier_status ON frontier(status, depth, added_at);

CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts USING fts5(
  title, body,
  content='documents', content_rowid='id',
  tokenize='unicode61 remove_diacritics 2'
);
CREATE VIRTUAL TABLE IF NOT EXISTS docs_vocab USING fts5vocab(docs_fts, 'row');

CREATE TRIGGER IF NOT EXISTS docs_ai AFTER INSERT ON documents BEGIN
  INSERT INTO docs_fts(rowid, title, body) VALUES (new.id, new.title, new.body);
END;
CREATE TRIGGER IF NOT EXISTS docs_ad AFTER DELETE ON documents BEGIN
  INSERT INTO docs_fts(docs_fts, rowid, title, body) VALUES('delete', old.id, old.title, old.body);
END;
CREATE TRIGGER IF NOT EXISTS docs_au AFTER UPDATE OF title, body ON documents BEGIN
  INSERT INTO docs_fts(docs_fts, rowid, title, body) VALUES('delete', old.id, old.title, old.body);
  INSERT INTO docs_fts(rowid, title, body) VALUES (new.id, new.title, new.body);
END;
"""


def init_db(path: str | None = None) -> None:
    con = sqlite3.connect(path or settings.db_path, isolation_level=None)
    try:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(SCHEMA)
    finally:
        con.close()


@contextmanager
def db(path: str | None = None):
    con = sqlite3.connect(path or settings.db_path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()
