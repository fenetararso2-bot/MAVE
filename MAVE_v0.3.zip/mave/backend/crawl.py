"""CLI: python crawl.py seeds.txt --pages 200 --depth 2 --delay 1.0"""
import argparse

from app.crawler import Crawler
from app.db import init_db

ap = argparse.ArgumentParser()
ap.add_argument("seeds", help="text file with one URL per line")
ap.add_argument("--pages", type=int, default=100)
ap.add_argument("--depth", type=int, default=2)
ap.add_argument("--delay", type=float, default=1.0)
args = ap.parse_args()

init_db()
urls = [l.strip() for l in open(args.seeds, encoding="utf-8") if l.strip() and not l.startswith("#")]
print(Crawler(max_pages=args.pages, max_depth=args.depth, delay=args.delay).run(urls))
